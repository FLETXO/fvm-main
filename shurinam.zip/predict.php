<?php
/* =====================================================
   SHURINAM PREDICTOR – SINGLE FILE BACKEND (PHP)
   Author: FVM
   ===================================================== */

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// ---------- BASIC SECURITY ----------
$SECRET_KEY = "FVM_SECURE_2026";   // 🔴 CHANGE THIS
$RATE_LIMIT_SECONDS = 10;

session_start();
if (isset($_SESSION['last_hit']) && time() - $_SESSION['last_hit'] < $RATE_LIMIT_SECONDS) {
    echo json_encode([
        "status" => false,
        "error" => "Too many requests"
    ]);
    exit;
}
$_SESSION['last_hit'] = time();

// ---------- TOKEN CHECK ----------
$input = json_decode(file_get_contents("php://input"), true);
if (!isset($input['token']) || $input['token'] !== hash("sha256", $SECRET_KEY . date("Y-m-d"))) {
    echo json_encode([
        "status" => false,
        "error" => "Invalid token"
    ]);
    exit;
}

// ---------- GAME HISTORY API ----------
$HISTORY_API = "https://draw.ar-lottery01.com/WinGo/WinGo_1M/GetHistoryIssuePage.json?ts=" . time();

$ch = curl_init($HISTORY_API);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 10,
    CURLOPT_SSL_VERIFYPEER => false
]);
$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);
if (!isset($data['data']['list'])) {
    echo json_encode([
        "status" => false,
        "error" => "Game API error"
    ]);
    exit;
}

$history = array_slice($data['data']['list'], 0, 10);

// ---------- ANALYSIS ----------
$big = 0;
$small = 0;
$numbers = [];

foreach ($history as $row) {
    $num = intval($row['number']);
    $numbers[] = $num;
    if ($num >= 5) $big++; else $small++;
}

// ---------- PREDICTION LOGIC ----------
if ($big > $small) {
    $prediction = "SMALL";
    $reason = "BIG streak detected, reversal logic";
    $confidence = rand(62, 74);
} elseif ($small > $big) {
    $prediction = "BIG";
    $reason = "SMALL streak detected, reversal logic";
    $confidence = rand(62, 74);
} else {
    $prediction = rand(0,1) ? "BIG" : "SMALL";
    $reason = "Balanced trend, probability based";
    $confidence = rand(55, 65);
}

// ---------- PERIOD ----------
$currentPeriod = $history[0]['issueNumber'] ?? "N/A";

// ---------- RESPONSE ----------
echo json_encode([
    "status" => true,
    "period" => $currentPeriod,
    "prediction" => $prediction,
    "confidence" => $confidence,
    "reason" => $reason,
    "server_time" => date("H:i:s")
]);